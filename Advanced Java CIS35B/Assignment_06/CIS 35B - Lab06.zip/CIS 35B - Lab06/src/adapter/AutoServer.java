package adapter;

import util.Properties;

public interface AutoServer {
    // Given a Properties object, buildAuto() builds an instance of Automobile.
    public void buildAuto(Properties properties);
}