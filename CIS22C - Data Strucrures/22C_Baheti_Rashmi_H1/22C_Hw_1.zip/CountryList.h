// Specification file for the CountryList class
#ifndef COUNTRYLIST_H
#define COUNTRYLIST_H

#include <iomanip>
#include <string>
#include <cstring>

using namespace std;

struct Country
{
    char code[3]; // 2 + 1 for '\0'
    string name;
    string capital;
    int population;
};

struct ListNode
{
    Country country;
    ListNode *next;
};

class CountryList
{
   private:
   ListNode *head;  // pointer to the first node in the list
   int cnt;         // keeps track of the number of countries in the list

   public:
   CountryList();   // Constructor
    ~CountryList(); // Destructor

   // Basic Linked List Operations
   int getCount() { return cnt;}
   void insertNode(Country);
   int deleteNode(const char*);
   void displayList() const;
   Country* findCountry(const char*);

};
#endif
