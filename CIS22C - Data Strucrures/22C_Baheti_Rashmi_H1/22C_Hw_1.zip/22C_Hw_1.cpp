// Written by A. Student
//
// Modified by: <your name>
// IDE:
//
//This program creates a linked list to store Country objects from a text file. Each object contains
//information such as the country code, name, capital, and population. The user may
//view a table of all countries and their information, delete a country from the list,
//or search for a specific country and its information.
//
#include <iostream>
#include <cstdlib>   // needed for the exit() function
#include <fstream>
#include "CountryList.h"
using namespace std;

#define INPUT_FILE "countries.txt"

void loadCountries(CountryList &list, const char *filename);
void requestAction(CountryList &list);
void requestSearch(CountryList &list);
void requestDeletes(CountryList &list);

int main()
{
   CountryList list;

   loadCountries(list, INPUT_FILE);
   requestAction(list);

   return 0;
}
//***********************************************
// Builds a sorted linked list from an input file
//***********************************************
void loadCountries(CountryList &list, const char *filename)
{
    ifstream inputFile;
    Country newCountry;
    string temp;

    // open the input file
    inputFile.open(filename);
    if(!inputFile){
        cout << "Error opening file \"" << filename << "\"\n";
        exit(1);
    }
    //Read each line of text into its own country object, then insert it into the list
    while(inputFile >> newCountry.code){
        //getline discards the delimiter ';' while preserving the space
        getline(inputFile, newCountry.name, ';');
        getline(inputFile, newCountry.capital, ';');
        //inputFile >> as opposed to getline to avoid string to int conversion
        inputFile >> newCountry.population;
        list.insertNode(newCountry);
    }
    inputFile.close();
}
//***********************************************
// Menu Manger: displays a menu
// and calls the requested function
//***********************************************
void requestAction(CountryList &list)
{
    cout << "What would you like to do?" << endl;
    string input = "1";
    do{
        cout << "1: Display countries\t" << "2: Search for a country\t"
             << "3: Delete a country\t" << "4: exit" << endl;
        getline(cin, input);
        cout << endl;
        //If valid input, execute corresponding functionality"
        if(input == "1" || input == "2" || input == "3" || input == "4"){
            //Process input
            if(input == "1"){
                list.displayList();
                cout << "Number of countries in the list: " << list.getCount() << "\n\n";
            }else if(input == "2"){
                requestSearch(list);
            }else if(input == "3"){
                requestDeletes(list);
                cout << "Number of countries in the list: " << list.getCount() << "\n\n";
            }
        }else{
            cout << "Please enter either 1, 2, 3, or 4" << endl;
        }
        //4 corresponds with the quit option
    }while(input != "4");
}

//***********************************************
// Search Manger: asks the user to enter a code,
// searches for that code and displays the
// information about that country or
// an error message if not found; repeats this
// process until the user enters QUIT.
//***********************************************
void requestSearch(CountryList &list){
    string input;
    do{
        //stores the result of the list.findCountry function
        Country* country = NULL;
        cout << "Please enter the code of a country you wish to search for or " << endl;
        cout << "type QUIT to return to the previous page" << endl;
        getline(cin, input);
        cout << endl;
        country = list.findCountry(input.c_str());
        //if country is still null display error message. Ignore this check if user is trying to quit
        if(!country && input != "QUIT"){
            cout << "Could not find a country with code: " << input << endl;
        }
        //Display country information if list.findCountry returned a country struct
        if(country){
            cout << "Found a match!" << endl;
            cout << "Country code: " << country->code << endl;
            cout << "Country name: " << country->name << endl;
            cout << "Country capital: " << country->capital << endl;
            cout << "Country population: " << country->population << endl;
        }
        cout << endl;
    }while(input != "QUIT");
}

//***********************************************
// Delete Manger: asks the user to enter a code,
// searches for that code and deletes it or
// displays an error message if not found;
// repeats this process until the user enters QUIT.
//***********************************************
void requestDeletes(CountryList &list){
    string input;
    do{
        //the errorCode is used to store the result of list.deleteNode to explain
        //to the user if the country was successfully deleted, if it could not be found,
        //or if the list is empty and they are wasting their time
        int errorCode;

        cout << "Please enter the code of the country you wish to delete or " << endl;
        cout << "type QUIT to return to the previous page" << endl;
        getline(cin, input);
        cout << endl;

        errorCode = list.deleteNode(input.c_str());

        if(errorCode == -1){
            cout << "There no countries left to delete!" << endl;
        }else if(errorCode == 0 && input != "QUIT"){
            cout << "Could not find country with code: " << input << endl;
        }else if(errorCode == 1){
            cout << input << " has been deleted" << endl << endl;
        }
        cout << endl;

    }while(input != "QUIT");
}

/*****************************************************************************
******************************SAMPLE OUTPUT***********************************
******************************************************************************

What would you like to do?
1: Display countries    2: Search for a country 3: Delete a country     4: exit
1

--Code-------------Country-------------Capital-----Population
-------------------------------------------------------------
   AU            Australia            Canberra       20090437
   BR               Brazil            Brasilia      186112794
   BU             Bulgaria               Sofia        7262675
   CA               Canada              Ottawa       32805041
   CN                China             Beijing     1306313812
   DO   Dominican Republic       Santo Domingo        8950034
   EG                Egypt               Cairo       77505756
   ES                Spain              Madrid       40341462
   FJ                 Figi                Suva         893354
   FR               France               Paris       60656178
   GR               Greece              Athens       10668354
   HU              Hungary            Budapest       10006835
   IR                 Iran              Tehran       68017860
   JA                Japan               Tokyo      127288419
   LI        Liechtenstein               Vaduz          33717
   MC               Monaco              Monaco          32409
   MU            Mauritius          Port Louis        1230602
   MX               Mexico         Mexico City      106202903
   NP                Nepal           Kathmandu       27676547
   RU               Russia              Moscow      143420309
   TW               Taiwan              Taipei       22894384
   US        United States      Washington, DC      295734134

1: Display countries    2: Search for a country 3: Delete a country     4: exit
2

Please enter the code of a country you wish to search for or
type QUIT to return to the previous page
HU

Found a match!
Country code: HU
Country name:  Hungary
Country capital:  Budapest
Country population: 10006835

Please enter the code of a country you wish to search for or
type QUIT to return to the previous page
QUIT


1: Display countries    2: Search for a country 3: Delete a country     4: exit
3

Please enter the code of the country you wish to delete or
type QUIT to return to the previous page
HU

HU has been deleted


Please enter the code of the country you wish to delete or
type QUIT to return to the previous page
QUIT


1: Display countries    2: Search for a country 3: Delete a country     4: exit
2

Please enter the code of a country you wish to search for or
type QUIT to return to the previous page
HU

Could not find a country with code: HU

Please enter the code of a country you wish to search for or
type QUIT to return to the previous page
QUIT


1: Display countries    2: Search for a country 3: Delete a country     4: exit
1

--Code-------------Country-------------Capital-----Population
-------------------------------------------------------------
   AU            Australia            Canberra       20090437
   BR               Brazil            Brasilia      186112794
   BU             Bulgaria               Sofia        7262675
   CA               Canada              Ottawa       32805041
   CN                China             Beijing     1306313812
   DO   Dominican Republic       Santo Domingo        8950034
   EG                Egypt               Cairo       77505756
   ES                Spain              Madrid       40341462
   FJ                 Figi                Suva         893354
   FR               France               Paris       60656178
   GR               Greece              Athens       10668354
   IR                 Iran              Tehran       68017860
   JA                Japan               Tokyo      127288419
   LI        Liechtenstein               Vaduz          33717
   MC               Monaco              Monaco          32409
   MU            Mauritius          Port Louis        1230602
   MX               Mexico         Mexico City      106202903
   NP                Nepal           Kathmandu       27676547
   RU               Russia              Moscow      143420309
   TW               Taiwan              Taipei       22894384
   US        United States      Washington, DC      295734134

1: Display countries    2: Search for a country 3: Delete a country     4: exit
4


Process returned 0 (0x0)   execution time : 20.354 s
Press any key to continue.


*/
