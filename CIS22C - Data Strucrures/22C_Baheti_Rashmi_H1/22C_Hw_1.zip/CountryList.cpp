// Implementation file for the CountryList class

#include <iostream>
#include "CountryList.h"
using namespace std;

//***************************************************************
// Constructor
//  - Allocates a sentinel node
//        --> an empty data node to be the first node in the list
//  - Set the counter to 0
//***************************************************************
CountryList::CountryList()
{
     head = new ListNode;
     head->next = NULL;
     cnt = 0;
}

//**************************************************
// displayList shows the country information
// stored in each node of the linked list
// pointed to by head.
//**************************************************

void CountryList::displayList() const
{
   ListNode *nodePtr;

   nodePtr = head->next;

   //Display the header
   cout << setfill('-');
   cout << setw(6) << "Code";
   cout << setw(20) << "Country";
   cout << setw(20) << "Capital";
   cout << setw(15) << "Population" <<  endl;
   for(int i = 0; i < 61; i++) { cout << '-'; }

   cout << endl << setfill(' ');
   while (nodePtr){
      // Display the information in the current node.
      cout << setw(5)  << nodePtr->country.code << " ";
      cout << setw(20) << nodePtr->country.name;
      cout << setw(20) << nodePtr->country.capital;
      cout << setw(15) << nodePtr->country.population << endl;
      // Move to the next node.
      nodePtr = nodePtr->next;
   }
   cout << endl;
}

//**************************************************
// The insertNode function inserts a node with
// countryIn copied to its country member.
//**************************************************
void CountryList::insertNode(Country countryIn)
{
    ListNode *newNode;             // A new node
    ListNode *nodePtr;             // To traverse the list
    ListNode *previousNode = NULL; // The previous node

    // Allocate a new node and store the country there.
    newNode = new ListNode;
    newNode->country = countryIn;

    previousNode = head;
    nodePtr = head->next;
    // Find the location of the new node in the sorted list
    while (nodePtr != NULL && strcmp(nodePtr->country.code, countryIn.code) < 0){
        previousNode = nodePtr;
        nodePtr = nodePtr->next;
    }
    // Update links and counter
    previousNode->next = newNode;
    newNode->next = nodePtr;
    cnt++;
}

//**************************************************
// The deleteNode function searches for a node
// with code as its code. The node, if found, is
// deleted from the list and from memory.
// It returns an error code
//      -1 represents an empty list
//      0 means the country was not found
//      1 means the country was deleted
//**************************************************
int CountryList::deleteNode(const char* code)
{
   ListNode *nodePtr;       // To traverse the list
   ListNode *previousNode;  // To point to the previous node

   // check if list is empty
   if (cnt == 0)
      return -1; // -1 for empty list

   nodePtr = head->next;
   // Search for the node to be deleted from the list
   while (nodePtr != NULL && strcmp(nodePtr->country.code, code) != 0){
       previousNode = nodePtr;
       nodePtr = nodePtr->next;
   }
   if (nodePtr){ // found
       previousNode->next = nodePtr->next;
       delete nodePtr;
       return 1; // 1 for success
   }
   return 0; // 0 for not found
}

//**************************************************
// Searches the list for a given country code
//  - returns a pointer to the country if found
//  - returns NULL if the country cannot be found
//**************************************************
Country* CountryList::findCountry(const char* code){
    ListNode *nodePtr;       // To traverse the list
    ListNode *previousNode;  // To point to the previous node

    // If the list is empty, return NULL
    if (cnt == 0)
        return NULL;

    nodePtr = head->next;
    previousNode = head;

    while (nodePtr != NULL && strcmp(nodePtr->country.code, code)){
        previousNode = nodePtr;
        nodePtr = nodePtr->next;
    }

    if (nodePtr){ // found
        return &nodePtr->country;
    }
   return NULL;
}
//**************************************************
// Destructor
// This function deletes every node in the list.
//**************************************************

CountryList::~CountryList()
{
   ListNode *nodePtr;   // To traverse the list
   ListNode *nextNode;  // To point to the next node

   // Position nodePtr at the head of the list.
   nodePtr = head;

   // While nodePtr is not at the end of the list...
   while (nodePtr != NULL){
      // Save a pointer to the next node.
      nextNode = nodePtr->next;
      // Delete the current node.
      delete nodePtr;
      // Position nodePtr at the next node.
      nodePtr = nextNode;
   }
}
