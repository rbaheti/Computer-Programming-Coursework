/**~*~*

  C++ implementation for a single-queue single-server queue

*~**/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

#include "Queue.h"

using namespace std;

#define SVC_TIME 5

struct Customer{
    int custNum;
    int arriveTime;
};

struct Cust_status{
    Customer customer;
    int      startTime;
    int      serviceTime;
};

struct Sim_Stats{
    int totCust;
    int totServiceTime;
    int totWaitTime;
    int maxQueueSize;
};

void welcome      (void);
void newCustomer  (Queue<Customer> *queue, int clock, int *custNum);
void serverFree   (Queue<Customer> *queue, int clock, Cust_status *status, int *moreCusts);
void srvcComplete (Queue<Customer> *queue, int clock, Cust_status *status, Sim_Stats *stats, int *moreCusts);
void printStats   (Sim_Stats stats);
void farewell     (void);

int main (void)
{
    Cust_status  custStatus;
    Sim_Stats    runStats = {0};
    Queue<Customer> *queue;
    int          clock;
    int          endTime;
    int          custNum;
    int          moreCusts;

	cout << "\n\n\tA model for a single-queue single-server queue \n\n";

    srand(time(NULL));
    queue      = new Queue<Customer>;
    clock      = 1;
    endTime    = 8 * 60;
    moreCusts  = 0;
    custNum    = 0;

    cout << "  ======== ======== ========= ======== ======== ========\n"
         << "  Customer Arrival  Start     Service  Waiting  Queue   \n"
         << "  Number   Time     Time      Time     Time     Size    \n"
         << "  ======== ======== ========= ======== ======== ========\n";

    while(clock <= endTime || moreCusts )
    {
		if(clock <= endTime)
			newCustomer   (queue, clock, &custNum);
		else
			moreCusts = 0;
        serverFree    (queue, clock, &custStatus, &moreCusts);
        srvcComplete  (queue, clock, &custStatus, &runStats, &moreCusts);

        if(!queue->isEmpty())
            moreCusts = 1;
        clock++;
    }
    printStats(runStats);

    delete queue;

    cout << "\n\t*** THE END ***\n";

	return 0;

}

/**~*~*
	Determines if a new customer has arrived.
	   PRE  : queue is a pointer to an initialized queue.
              clock is the current clock minute
	   POST : if new customer arrived, placed in queue
*~**/
void newCustomer (Queue<Customer> *queue, int clock, int *custNum)
{
    Customer newCustomer;
    int      arrival;

    arrival = rand()% 4 + 1;
    if(arrival == 4)  // new customer has arrived
    {
        (*custNum)++;
        newCustomer.custNum    = *custNum;
        newCustomer.arriveTime = clock;
        queue->enqueue(newCustomer);
    }
	return;
}

/**~*~*
	Determines if the server is idle and if so starts serving a new customer
	   PRE  : queue is a pointer to an initialized queue.
              clock is the current clock minute
              custStatus holds data about current/previous customer
	   POST : moreCusts is set to true if a call is started
*~**/
void serverFree (Queue<Customer> *queue, int clock, Cust_status *status, int *moreCusts)
{
    Customer customer;

    if(clock > status->startTime + status->serviceTime - 1) // server is idle
    {
       if(!queue->isEmpty())
       {
           queue->dequeue(customer);
           status->customer    = customer;
           status->startTime   = clock;
           status->serviceTime = rand() % SVC_TIME + 1;
           *moreCusts          = 1;
       }
    }
	return;
}

/**~*~*
	Determines if the current customer's processing is complete
	   PRE  : queue is a pointer to an initialized queue.
              clock is the current clock minute
              custStatus holds data about current/previous customer
	   POST : if service complete, data for current customer printed
              and simulation statistics updated
              moreCusts set to false if call completed
*~**/
void srvcComplete (Queue<Customer> *queue, int clock, Cust_status *status, Sim_Stats *stats, int *moreCusts)
{
    int waitTime;
    int queueSize;

    if(clock == status->startTime + status->serviceTime - 1) // current call complete
    {
        waitTime = status->startTime - status->customer.arriveTime;
        stats->totCust++;
        stats->totServiceTime += status->serviceTime;
        stats->totWaitTime    += waitTime;
        queueSize = queue->getCount();
        if(stats->maxQueueSize < queueSize)
            stats->maxQueueSize = queueSize;
        cout << "\t"
             <<status->customer.custNum << "\t"
             << status->customer.arriveTime << "\t"
             << status->startTime << "\t"
             << status->serviceTime << "\t"
             << waitTime << "\t"
             << queueSize << endl;
        *moreCusts = 0;
    }

	return;

}

/**~*~*
	Prints the statistics for the simulation.
	   PRE  : stats contains the run statistics
	   POST : statistics printed
*~**/
void printStats (Sim_Stats stats)
{
    cout << "\n\t\tSimultation Statistics"
         << "\n\t\t=========== ==========\n\n"
         << "\t\tTotal customers     : \t" << stats.totCust << endl
         << "\t\tTotal service time  : \t" << stats.totServiceTime << "min\n"
         << "\t\tAverage service time: \t" << (double)stats.totServiceTime / stats.totCust << "min\n"
         << "\t\tAverage wait time   : \t" << (double)stats.totWaitTime / stats.totCust << "min\n"
         << "\t\tMaximum queue size  : \t" << stats.maxQueueSize << endl;

	return;

}

/**~*~*

        A model for a single-queue single-server queue

  ======== ======== ========= ======== ======== ========
  Customer Arrival  Start     Service  Waiting  Queue
  Number   Time     Time      Time     Time     Size
  ======== ======== ========= ======== ======== ========
        1       8       8       2       0       0
        2       10      10      5       0       1
        3       11      15      5       4       1
        4       15      20      4       5       0
        5       26      26      4       0       0
        6       36      36      5       0       1
        7       40      41      2       1       0
        8       50      50      2       0       1
        9       51      52      5       1       1
        10      55      57      2       2       1
        11      58      59      1       1       0
        12      71      71      4       0       1
        13      74      75      2       1       1
        14      76      77      3       1       0
        15      83      83      5       0       0
        16      96      96      3       0       2
        17      97      99      1       2       1
        18      98      100     5       2       1
        19      103     105     5       2       2
        20      108     110     1       2       1
        21      109     111     4       2       3
        22      111     115     3       4       2
        23      112     118     3       6       1
        24      113     121     1       8       0
        25      122     122     4       0       1
        26      125     126     1       1       0
        27      132     132     5       0       1
        28      133     137     5       4       0
        29      145     145     3       0       1
        30      147     148     3       1       1
        31      149     151     2       2       0
        32      154     154     5       0       0
        33      162     162     5       0       3
        34      164     167     2       3       3
        35      165     169     1       4       2
        36      166     170     3       4       2
        37      167     173     2       6       1
        38      172     175     2       3       0
        39      183     183     1       0       0
        40      184     184     2       0       0
        41      188     188     1       0       0
        42      189     189     2       0       0
        43      194     194     3       0       1
        44      195     197     2       2       0
        45      199     199     1       0       0
        46      201     201     4       0       1
        47      203     205     4       2       2
        48      206     209     4       3       1
        49      207     213     2       6       0
        50      221     221     3       0       0
        51      227     227     3       0       0
        52      231     231     5       0       0
        53      238     238     3       0       1
        54      240     241     5       1       1
        55      242     246     2       4       0
        56      254     254     4       0       2
        57      255     258     5       3       1
        58      256     263     5       7       1
        59      265     268     2       3       0
        60      270     270     3       0       0
        61      280     280     3       0       1
        62      281     283     5       2       1
        63      284     288     2       4       0
        64      291     291     5       0       2
        65      293     296     3       3       4
        66      294     299     1       5       4
        67      296     300     3       4       3
        68      297     303     4       6       4
        69      298     307     2       9       4
        70      299     309     2       10      3
        71      303     311     1       8       2
        72      305     312     5       7       3
        73      307     317     3       10      2
        74      312     320     4       8       2
        75      314     324     4       10      1
        76      322     328     1       6       0
        77      332     332     1       0       0
        78      333     333     5       0       2
        79      335     338     3       3       3
        80      337     341     1       4       2
        81      338     342     5       4       3
        82      339     347     3       8       2
        83      345     350     5       5       2
        84      346     355     4       9       3
        85      354     359     2       5       2
        86      355     361     5       6       1
        87      358     366     5       8       1
        88      370     371     1       1       0
        89      374     374     3       0       1
        90      375     377     1       2       0
        91      379     379     4       0       0
        92      389     389     5       0       3
        93      391     394     5       3       3
        94      392     399     5       7       2
        95      393     404     1       11      2
        96      397     405     1       8       1
        97      404     406     2       2       1
        98      406     408     3       2       0
        99      413     413     4       0       0
        100     417     417     3       0       0
        101     422     422     3       0       1
        102     424     425     2       1       1
        103     426     427     1       1       0
        104     430     430     5       0       1
        105     433     435     3       2       1
        106     435     438     4       3       0
        107     442     442     3       0       0
        108     452     452     5       0       0
        109     459     459     4       0       1
        110     461     463     1       2       1
        111     463     464     3       1       2
        112     464     467     2       3       1
        113     466     469     5       3       1
        114     469     474     1       5       0

                Simultation Statistics
                =========== ==========

                Total customers     :   114
                Total service time  :   353min
                Average service time:   3.09649min
                Average wait time   :   2.66667min
                Maximum queue size  :   4

        *** THE END ***
*~**/
