/**~*~*
  This program demonstrates two basic queue operations:
  enqueue and dequeue
*~**/
#include <iostream>
#include <string>
#include "Queue.h"
using namespace std;

// Constants for the menu choices
const int ENQUEUE_CHOICE = 1,
          DEQUEUE_CHOICE  = 2,
          QUIT_CHOICE = 3;

// Function prototypes
int menu();
int getValidNum(int low, int high);
void insertItem(Queue<string> *);
void deleteItem(Queue<string> *);

int main()
{
    int choice;    // To hold a menu choice

    // Create the queue.
    Queue<string> *queue = new Queue<string>;

    while ((choice = menu())!= QUIT_CHOICE)
    {
        switch (choice)
        {
           case ENQUEUE_CHOICE:
                insertItem(queue);
                break;
           case DEQUEUE_CHOICE:
                deleteItem(queue);
        }
    }

    delete queue;
    cout << "\n\t*** THE END ***\n";
    return 0;
}

/**~*~*
   The menu function displays the menu and gets
   the user's choice, which is returned to
   the caller.
*~**/
int menu()
{
    int choice;
     // Display the menu and get the user's choice.
     cout << "\nWhat do you want to do?\n\t"
          << ENQUEUE_CHOICE
          << " - Insert an item into the queue\n\t"
          << DEQUEUE_CHOICE
          << " - Remove an item from the queue\n\t"
          << QUIT_CHOICE
          << " - Quit the program\n"
          << "Enter your choice: ";

     choice = getValidNum(ENQUEUE_CHOICE, QUIT_CHOICE);
     return choice;
}

/**~*~*
   The insertItem function gets an item from the
   user and inserts it into the queue.
*~**/
void insertItem(Queue<string> *queue)
{
     string item;

     // Get an item to be inserted into the queue
     cout << "\nEnter an item: ";
     getline(cin, item);
     queue->enqueue(item);
}

/**~*~*
   The deleteItem function removes an item from the queue
*~**/
void deleteItem(Queue<string> *queue)
{
     bool status;
     string item = "";

     // Remove the item.
     status = queue->dequeue(item);

     // Display the item.
     if (status)
        cout << "\n\t" << item << " was deleted.\n\n";
     else
        cout << "\n\t*** Empty queue! ***\n\n";
}

/**~*~*
   This function prompts the user to enter an integer number within a given range
   If the input is not valid (not a number or if it is outside of the range) it
   prompts the user to enter a new number, until the input is valid.
*~**/
int getValidNum(int low, int high)
{
    int num;
    bool success;

    do
    {
        cout << "Please enter a number (" << low << " to " << high << "): ";
        success = cin >> num;
        cin.clear();          // to clear the error flag
        cin.ignore(80, '\n'); // to discard the unwanted input from the input buffer
    }while(!success || num < low || num > high);

    return num;
}

/**~*~*
What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 1

Enter an item: cat

What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 1

Enter an item: dog

What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 2

        cat was deleted.


What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 1

Enter an item: mouse

What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 2

        dog was deleted.


What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 2

        mouse was deleted.


What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 2

        *** Empty queue! ***


What do you want to do?
        1 - Insert an item into the queue
        2 - Remove an item from the queue
        3 - Quit the program
Enter your choice: Please enter a number (1 to 3): 3

        *** THE END ***
*~**/
